#include "Vue.h"
#include <iostream>

const char Vue::representation[3] { '-', 'O', 'X' };

void Vue::executer() {

    int gagnant = 0;
    while ((gagnant == 0) && ! m_modele.grille_pleine())
    {
        afficher();

        int ligne, colonne;
        demander_coordonnees(ligne, colonne);
        if (m_modele.jouer(ligne, colonne)) {
	  gagnant = m_modele.gagnant(); // 1 ou 2, ou 0
        } else {
            std::cout << "* Pas possible de jouer en "
	              << (char)('a'+ligne) << (char)('a'+colonne)
                      << " (" << ligne<< " " << colonne << ")"
                      << std::endl;
        }
    }
    afficher();
    std::cout << "Gagnant = " << representation[gagnant]
                 << std::endl;
}

// -----------------------------------------------------------

void Vue::demander_coordonnees(int &ligne, int &colonne) const
{
    std::cout << "Le joueur "
              << representation[m_modele.joueur()]
              << " joue en : ";

    // saisie de 2 caractères, et conversion en indices
    char l, c;
    std::cin >> l >> c;
    ligne   = l - 'a';
    colonne = c - 'a';
}

// -------------------------------------------------------------

void Vue::afficher() const {
    std::cout << "Il faut aligner 3 ronds ou croix"
              << std::endl;
    std::cout << "  ";
    for (int c = 0; c < 3; c++) {
        std::cout << " " << (char) ('a'+c);
    }
    std::cout << std::endl;
    for (int l = 0; l < 3 ; l++) {
        std::cout << (char)('a'+l) << " ";
        for (int c = 0; c < 3; c++) {
            std::cout << " "
                      << representation[m_modele.contenu(l,c)];
        }
        std::cout << std::endl;
    }
}
