#include "Modele.h"

/* Tableau 3x3 d'entiers */

Modele::Modele()
{
    // TODO
    reinitialiser();
}

void Modele::reinitialiser()
{
    // vider la grille (0 partout)
    // c'est au joueur 1 de jouer
 }

int Modele::joueur() const
{
    return m_joueur;
}

bool Modele::grille_pleine() const
{
    return false; // A CHANGER
}

bool Modele::jouer(int ligne, int colonne)
{
    // vérifier que ligne et colonne entre 0 et 2
    // et que la case est vide
    // sinon retourner faux

    // si ok, mettre le numero du joueur dans la case
    // et donner le tour à l'autre (changer le joueur)

    return false; // A CHANGER
}

int Modele::contenu(int ligne, int colonne) const
{
    // le contenu de la case
    return 0;
}

int Modele::gagnant() const
{
    // chercher un alignement sur les 3 lignes
    for (int l=0; l<3; l++) {
        int j = m_tab[l][0];
        if ((j != 0)
                && (j == m_tab[l][1])
                && (j == m_tab[l][2]))
        {
            return j;
        }
    }

    // idem pour les trois colonnes
    // idem pour les deux diagonales

    return 0; // pas d'alignement
}
