#include <iostream>

#include "Vue.h"

using namespace std;

int main()
{
    Vue j;
    j.executer();

    return 0;
}

