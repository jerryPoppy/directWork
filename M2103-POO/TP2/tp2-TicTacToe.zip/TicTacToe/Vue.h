#ifndef VUE_H
#define VUE_H

#include "Modele.h"

class Vue
{
public:
    void executer();

private:
    Modele m_modele;
    static const char representation[3]; // décl. constante

    void afficher()                             const;
    void demander_coordonnees(int & ligne,
                              int & colonne)    const;
};

#endif // JEU_H
