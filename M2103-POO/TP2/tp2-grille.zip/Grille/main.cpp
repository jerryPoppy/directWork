#include <SFML/Graphics.hpp>
#include <iostream>


#include "Appli.h"

int main ()
{
    Appli a;
    a.run();
    return 0;
}

