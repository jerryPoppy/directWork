#ifndef APPLI_H
#define APPLI_H
#include <SFML/Graphics.hpp>
class Appli
{
public:
    Appli();
    void run();

private:

    sf::RenderWindow   m_fenetre;
    sf::CircleShape    m_led;
    sf::RectangleShape m_repere;

    bool m_leds[10][10];
    int m_l, m_c;

    void traiter_evenements();
    void dessiner();

    static const float MARGE_HAUT;
    static const float MARGE_GAUCHE;
    static const float LARGEUR;
    static const float HAUTEUR;
    static const float RAYON;
    static const float COTE;
    static const float EPAISSEUR;

    static sf::Vector2f position(int l, int c);
};

#endif // APPLI_H
