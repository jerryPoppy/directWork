#include "Appli.h"
#include <SFML/Graphics.hpp>

/*
 constantes et fonction auxiliaires
 pour l'implémentation de Appli
*/

const float Appli::MARGE_HAUT   = 100.0;
const float Appli::MARGE_GAUCHE = 100.0;
const float Appli::LARGEUR      = 40.0;
const float Appli::HAUTEUR        = 40.0;
const float Appli::RAYON          = 5.0;
const float Appli::COTE     = 12.0;
const float Appli::EPAISSEUR = 1.0;

sf::Vector2f Appli::position(int l, int c)
{
  return {MARGE_GAUCHE + c * LARGEUR,
      MARGE_HAUT   + l * HAUTEUR};
}

// ---------------------------------------

Appli::Appli()
    : m_fenetre {sf::VideoMode {800, 600, 32},
                 "Exemple 2",
                 sf::Style::Close
                 }
    , m_led(RAYON)
    , m_repere({COTE, COTE})
    , m_l {0}
    , m_c {0}

{
    m_fenetre.setFramerateLimit(50);
    m_led.setOrigin({RAYON, RAYON});
    m_repere.setOrigin({COTE/2, COTE/2});
    m_repere.setFillColor(sf::Color::Transparent);
    m_repere.setOutlineThickness(EPAISSEUR);
    m_repere.setOutlineColor(sf::Color::White);

    for (int l=0; l<9; l++)
        for (int c=0; c<9; c++)
            m_leds[l][c] = false;
}

// ---------------------------------------

void Appli::run()
{
    while (m_fenetre.isOpen())
    {
        traiter_evenements();
        dessiner();
    }
}

// ---------------------------------------

void Appli::traiter_evenements()
{
    sf::Event evenement;
    while (m_fenetre.pollEvent(evenement)) {
      switch (evenement.type) {
      case sf::Event::Closed : // gestionnaire de fenêtre
        m_fenetre.close();
        break;
      case  sf::Event::KeyPressed : // clavier
        switch (evenement.key.code) {
        case  sf::Keyboard::Escape :  // touche échappement
          m_fenetre.close();
          break;
        case  sf::Keyboard::Up   : if (m_l > 0) m_l--; break;
        case  sf::Keyboard::Down : if (m_l < 9) m_l++; break;
        case  sf::Keyboard::Left : if (m_c > 0) m_c--; break;
        case  sf::Keyboard::Right: if (m_c < 9) m_c++; break;

        case  sf::Keyboard::Space:
            m_leds[m_l][m_c] = ! m_leds[m_l][m_c];
            break;

        default:
          // autre touche
      break;
        };
      default:
        // autre événement
    break;
      }
    }
}

// ---------------------------------------

void Appli::dessiner()
{
    m_fenetre.clear(sf::Color::Black);
    for (int l=0; l<9; l++) {
        for (int c=0; c<9; c++) {
            m_led.setPosition(position(l,c));
            m_led.setFillColor( m_leds[l][c]
                                ? sf::Color::Red
                                : sf::Color::White);
            m_fenetre.draw(m_led);
        }
    }

    m_repere.setPosition(position(m_l, m_c));
    m_fenetre.draw(m_repere);

    m_fenetre.display();

}
