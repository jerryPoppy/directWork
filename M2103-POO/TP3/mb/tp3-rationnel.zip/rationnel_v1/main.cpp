#define BOOST_TEST_DYN_LINK
#define BOOST_TEST_MODULE TestsRationnels

#include <boost/test/unit_test.hpp>
#include "Rationnel.h"
#include "pgcd.h"

BOOST_AUTO_TEST_CASE(signes)
{
    Rationnel r1{1, 2};
    BOOST_CHECK(r1.getNum() == 1);
    BOOST_CHECK(r1.getDen() == 2);

    Rationnel s1{3 };
    BOOST_CHECK(s1.getNum() == 3);
    BOOST_CHECK(s1.getDen() == 1);

    Rationnel s2;
    BOOST_CHECK(s2.getNum() == 0);
    BOOST_CHECK(s2.getDen() == 1);

    Rationnel r2{-1, 2};
    BOOST_CHECK(r2.getNum() == -1);
    BOOST_CHECK(r2.getDen() == 2);

    Rationnel r3{1, -2};
    BOOST_CHECK(r3.getNum() == -1);
    BOOST_CHECK(r3.getDen() == 2);

    Rationnel r4{-1, -2};
    BOOST_CHECK(r4.getNum() == 1);
    BOOST_CHECK(r4.getDen() == 2);

    Rationnel z1{0, 2};
    BOOST_CHECK(z1.getNum() == 0);
    BOOST_CHECK(z1.getDen() == 1);

    Rationnel z2{0, -2};
    BOOST_CHECK(z2.getNum() == 0);
    BOOST_CHECK(z2.getDen() == 1);
}

/*
BOOST_AUTO_TEST_CASE(simplifications)
{
    Rationnel r1{0,2};
    BOOST_CHECK(r1.getNum() == 0);
    BOOST_CHECK(r1.getDen() == 2);

    Rationnel r2{12, 16};
    BOOST_CHECK(r2.getNum() == 3);
    BOOST_CHECK(r2.getDen() == 4);

    Rationnel r3{-20, 30};
    BOOST_CHECK(r3.getNum() == -2);
    BOOST_CHECK(r3.getDen() == 3);
}
*/

/*
BOOST_AUTO_CASE(comparaisons)
{
   Rationnel r1{3,6}, r2{-2,-4}, r3;
   // introduire operator==
   BOOST_CHECK( r1 == r2 );
   BOOST_CHECK(!(r1 == r3));

   BOOST_CHECK(! (r1 != r2));
   BOOST_CHECK( r1 != r3 );
}
*/

/*

BOOST_AUTO_CASE(mutateurs)
{
    Rationnel r1{1,2};
    r1.setNum(6);
    BOOST_CHECK(r1.getNum() == 3);
    BOOST_CHECK(r1.getDen() == 1);

    // à développer
}

*/

/*
BOOST_AUTO_CASE(somme)
{
    Rationnel r1{1,2};
    Rationnel r2{1,3);
    Rationnel r3;
    r3 = r1 + r2;

    BOOST_CHECK(r3. ....)

    // à développer
}

BOOST_AUTO_CASE(toString)
{
}

*/
