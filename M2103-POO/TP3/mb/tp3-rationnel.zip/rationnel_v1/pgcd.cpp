#include <cassert>

int pgcd(unsigned int a, unsigned int b)
{
    while (b != 0) {
        int r = a % b;
        a = b;
        b = r;
    };
    return a;
 }
