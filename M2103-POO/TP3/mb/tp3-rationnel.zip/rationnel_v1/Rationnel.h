#ifndef RATIONNEL_H
#define RATIONNEL_H

class Rationnel
{
private:
    int m_num;
    int m_den;
    void normaliser();

public:
    Rationnel(int n, int d);
    Rationnel(int n);
    Rationnel();

    int getNum() const;
    int getDen() const;
};

#endif // RATIONNEL_H
