#ifndef PGCD_H
#define PGCD_H

int pgcd(unsigned int a, unsigned int b);

#endif // PGCD_H
