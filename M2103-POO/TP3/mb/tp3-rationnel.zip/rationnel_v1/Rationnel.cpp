#include "Rationnel.h"
#include "pgcd.h"

Rationnel::Rationnel(int n, int d)
    : m_num{n}
    , m_den{d}
{
    normaliser();
}

void Rationnel::normaliser()
{
    // met le rationnel sous forme réduite :
    // - dénominateur
    // - numérateur et dénominateur sans diviseur commun

    // a faire
}

Rationnel::Rationnel(int n)
{
    // on fournit un entier
    // todo
}

Rationnel::Rationnel()
{
    // = zero
    // todo
}

int Rationnel::getNum() const {
    return m_num;
}

int Rationnel::getDen() const {
    return m_den;
}
