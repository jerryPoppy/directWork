/*
 * Affiche un texte et deux figures (rond et carré)
 * appui sur x => les figures changent de position
 * échappement ou fermeture fenêtre => arrêt
 */

#include <SFML/Graphics.hpp>
#include <iostream>
#include <cassert>

constexpr float rayon_cercle = 40.;
constexpr float cote_carre =   50.;

int main ()
{
  // création de la fenêtre de l'application
  // 800 x 600, avec 32 bits par pixel

  sf::RenderWindow fenetre {sf::VideoMode {800, 600, 32},
                            "Exemple 1",
                            sf::Style::Close
                           };
  fenetre.setFramerateLimit(20); // images par seconde

  // Préparation de 2 formes et d'un texte

  sf::RectangleShape carre {sf::Vector2f {cote_carre,
	                                  cote_carre}};
  carre.setOrigin(cote_carre/2, cote_carre/2);
  carre.setFillColor(sf::Color::Red);

  sf::CircleShape rond {rayon_cercle};
  rond.setOrigin(rayon_cercle, rayon_cercle);
  rond.setFillColor(sf::Color::Green);

  sf::Font police;
  assert(police.loadFromFile(
   "/usr/share/fonts/truetype/msttcorefonts/arial.ttf"
			     ));

  sf::Text texte;
  texte.setString(L"Un carré et un cercle");
  texte.setFont(police);
  texte.setColor(sf::Color::Yellow);

  // Positions
  
  sf::Vector2f position_carre {350, 300};
  sf::Vector2f position_rond  {450, 300};

  // 
  // boucle de travail 

  while (fenetre.isOpen()) {

    // traitement des évènements en attente

    sf::Event evenement;
    while (fenetre.pollEvent(evenement)) {
      switch (evenement.type) {
      case sf::Event::Closed : // gestionnaire de fenêtre
        fenetre.close();
        break;
      case  sf::Event::KeyPressed : // clavier
        switch (evenement.key.code) {
        case  sf::Keyboard::Escape :  // touche échappement
          fenetre.close();
          break;
        case  sf::Keyboard::X : {     // touche x
          // échange des positions
          sf::Vector2f tmp {position_carre};
          position_carre = position_rond;
          position_rond = tmp;
        }
        break;
        default:
          // autre touche
	  break;
        };
      default:
        // autre événement
	break;
      }
    }

    // mise à jour de l'affichage

    fenetre.clear(sf::Color::Black); // effacer

    texte.setPosition(100, 100);
    fenetre.draw(texte);             // dessiner

    carre.setPosition(position_carre);
    fenetre.draw(carre);             // dessiner

    rond.setPosition(position_rond);
    fenetre.draw(rond);              // dessiner

    fenetre.display();               // et afficher
  }
  return 0;
}
